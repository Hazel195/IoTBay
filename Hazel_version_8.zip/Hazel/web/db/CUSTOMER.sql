/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  soyoung
 * Created: 13/05/2020
 */

CREATE TABLE CUSTOMER (
    EMAIL VARCHAR (40),
    NAME VARCHAR (40),
    PASSWORD VARCHAR (40),
    ADDRESS VARCHAR (40),
    POSTCODE VARCHAR (40),
    CONTACTNUM VARCHAR (40)
);