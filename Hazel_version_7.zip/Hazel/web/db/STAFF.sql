/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  bert_
 * Created: 13/05/2020
 */

CREATE TABLE STAFF (
    EMAIL VARCHAR (40),
    NAME VARCHAR (40),
    PASSWORD VARCHAR (40),
    CONTACTNUM VARCHAR (40),
    POSITION VARCHAR (40),
    SALARY VARCHAR (40)
);