/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import model.Customer;
import java.sql.*;
import java.util.ArrayList;
import model.Staff;

/* 
* DBManager is the primary DAO class to interact with the database. 
* Complete the existing methods of this classes to perform CRUD operations with the db.
*/

public class DBManager {

    private Statement st;
   
    public DBManager(Connection conn) throws SQLException {       
        st = conn.createStatement();   
    }

//Find user by email and password in the database   
    public Customer findCustomer(String email, String password) throws SQLException {       
        //setup the select sql query string  
        //execute this query using the statement field 
        String fetch = "SELECT * FROM IOTUSER.CUSTOMER WHERE EMAIL ='"+ email +"'AND PASSWORD='"+ password +"'";
        //add the results to a ResultSet     
        ResultSet rs = st.executeQuery(fetch);       
        //add the results to a ResultSet       
        //search the ResultSet for a user using the parameters   
        while(rs.next()) {
            String customerEmail = rs.getString(1);
            String customerPass = rs.getString(3);
            if(customerEmail.equals(email) && customerPass.equals(password)){
                String customerName = rs.getString(2);
                String customerAddress = rs.getString(4);
                String customerPostcode = rs.getString(5);
                String customerContactNum = rs.getString(6);
                
                return new Customer(customerEmail,customerName,customerPass,customerAddress,customerPostcode,customerContactNum);
            }
        }            
        return null;   
    }
    
    public Staff findStaff(String email, String password) throws SQLException {       
        //setup the select sql query string  
        //execute this query using the statement field 
        String fetch = "SELECT * FROM IOTUSER.STAFF WHERE EMAIL ='"+ email +"'AND PASSWORD='"+ password +"'";
        //add the results to a ResultSet     
        ResultSet rs = st.executeQuery(fetch);       
        //add the results to a ResultSet       
        //search the ResultSet for a user using the parameters   
        while(rs.next()) {
            String staffEmail = rs.getString(1);
            String staffPass = rs.getString(3);
            if(staffEmail.equals(email) && staffPass.equals(password)){
                String staffName = rs.getString(2);
                String staffContactNum = rs.getString(4);
                String staffPosition = rs.getString(5);
                String staffSalary = rs.getString(6);
                
                return new Staff(staffEmail,staffName,staffPass,staffContactNum,staffPosition,staffSalary);
            }
        }            
        return null;   
    }

//Add a user-data into the database   
    public void addCustomer(String email, String name, String password, String address, String postcode, String contactnum) throws SQLException {                   //code for add-operation       
        st.executeUpdate("INSERT INTO IOTUSER.CUSTOMER " + "VALUES ('"+ email +"','"+ name +"','"+ password +"','"+address+"','"+postcode+"','"+contactnum+"')");   

    }

//update a user details in the database   
    public void updateCustomer(String curremail, String email, String name, String password, String address, String postcode, String contactnum) throws SQLException { 
        st.executeUpdate("UPDATE IOTUSER.CUSTOMER SET EMAIL='"+email+"',NAME='"+name+"',PASSWORD='"+password+"',ADDRESS='"+address+"',POSTCODE='"+postcode+"',CONTACTNUM='"+contactnum+"' WHERE EMAIL='"+curremail+"'");
   //code for update-operation   

    }       

//delete a user from the database   
    public void deleteCustomer(String email) throws SQLException{ 
        st.executeUpdate("DELETE FROM IOTUSER.CUSTOMER WHERE EMAIL='"+email+"'");
   //code for delete-operation   

    }

}
