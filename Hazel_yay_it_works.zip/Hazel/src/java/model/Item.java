/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author yujiwon
 */
public class Item implements Serializable {

    private int itemID;
    private String itemname;
    private String category;
    private boolean instock;
    private int price;
    private int instockquantity;
    private int manufactureid;
    
    public Item() {

    }

    public Item(int itemID, String itemname, String category, boolean instock, int price, int instockquantity, int manufactureid) {
        this.itemID = itemID;
        this.itemname = itemname;
        this.category = category;
        this.instock = instock;
        this.price = price;
        this.instockquantity = instockquantity;
        this.manufactureid = manufactureid;
    }

    public int getItemID() {
        return itemID;
    }

    public void setItemID(int itemID) {
        this.itemID = itemID;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public boolean isInstock() {
        return instock;
    }

    public void setInstock(boolean instock) {
        this.instock = instock;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getInstockquantity() {
        return instockquantity;
    }

    public void setInstockquantity(int instockquantity) {
        this.instockquantity = instockquantity;
    }

    public int getManufactureid() {
        return manufactureid;
    }

    public void setManufactureid(int manufactureid) {
        this.manufactureid = manufactureid;
    }

}
