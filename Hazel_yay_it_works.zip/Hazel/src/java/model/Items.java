/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author yujiwon
 */
public class Items implements Serializable {

    private String itemID;
    private String itemname;
    private String category;
    private String instock;
    private String price;
    private String instockquantity;
    private String manufactureid;
    
    public Items() 
    {

    }

    public Items(String itemID, String itemname, String category, String instock, String price, String instockquantity, String manufactureid) 
    {
        this.itemID = itemID;
        this.itemname = itemname;
        this.category = category;
        this.instock = instock;
        this.price = price;
        this.instockquantity = instockquantity;
        this.manufactureid = manufactureid;
    }

    public String getItemID() {
        return itemID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getInstock() {
        return instock;
    }

    public void setInstock(String instock) {
        this.instock = instock;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getInstockquantity() {
        return instockquantity;
    }

    public void setInstockquantity(String instockquantity) {
        this.instockquantity = instockquantity;
    }

    public String getManufactureid() {
        return manufactureid;
    }

    public void setManufactureid(String manufactureid) {
        this.manufactureid = manufactureid;
    }
}
