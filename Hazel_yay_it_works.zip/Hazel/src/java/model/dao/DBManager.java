/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import model.Customer;
import model.Shipment;
import java.sql.*;
import java.util.ArrayList;
import model.Item;
import model.Staff;

/* 
* DBManager is the primary DAO class to interact with the database. 
* Complete the existing methods of this classes to perform CRUD operations with the db.
*/

public class DBManager {

    private Statement st;
   
    public DBManager(Connection conn) throws SQLException {       
        st = conn.createStatement();   
    }

//Find user by email and password in the database   
    public Customer findCustomer(String email, String password) throws SQLException {       
        //setup the select sql query string  
        //execute this query using the statement field 
        String fetch = "SELECT * FROM IOTUSER.CUSTOMER WHERE EMAIL ='"+ email +"'AND PASSWORD='"+ password +"'";
        //add the results to a ResultSet     
        ResultSet rs = st.executeQuery(fetch);       
        //add the results to a ResultSet       
        //search the ResultSet for a user using the parameters   
        while(rs.next()) {
            String customerEmail = rs.getString(1);
            String customerPass = rs.getString(3);
            if(customerEmail.equals(email) && customerPass.equals(password)){
                String customerName = rs.getString(2);
                String customerAddress = rs.getString(4);
                String customerPostcode = rs.getString(5);
                String customerContactNum = rs.getString(6);
                
                return new Customer(customerEmail,customerName,customerPass,customerAddress,customerPostcode,customerContactNum);
            }
        }            
        return null;   
    }
    
    public Staff findStaff(String email, String password) throws SQLException {       
        //setup the select sql query string  
        //execute this query using the statement field 
        String fetch = "SELECT * FROM IOTUSER.STAFF WHERE EMAIL ='"+ email +"'AND PASSWORD='"+ password +"'";
        //add the results to a ResultSet     
        ResultSet rs = st.executeQuery(fetch);       
        //add the results to a ResultSet       
        //search the ResultSet for a user using the parameters   
        while(rs.next()) {
            String staffEmail = rs.getString(1);
            String staffPass = rs.getString(3);
            if(staffEmail.equals(email) && staffPass.equals(password)){
                String staffName = rs.getString(2);
                
                return new Staff(staffEmail,staffName,staffPass);
            }
        }            
        return null;   
    }

//Add a user-data into the database   
    public void addCustomer(String email, String name, String password, String address, String postcode, String contactnum) throws SQLException {                   //code for add-operation       
        st.executeUpdate("INSERT INTO IOTUSER.CUSTOMER " + "VALUES ('"+ email +"','"+ name +"','"+ password +"','"+address+"','"+postcode+"','"+contactnum+"')");   

    }

//update a user details in the database   
    public void updateCustomer(String curremail, String email, String name, String password, String address, String postcode, String contactnum) throws SQLException { 
        st.executeUpdate("UPDATE IOTUSER.CUSTOMER SET EMAIL='"+email+"',NAME='"+name+"',PASSWORD='"+password+"',ADDRESS='"+address+"',POSTCODE='"+postcode+"',CONTACTNUM='"+contactnum+"' WHERE EMAIL='"+curremail+"'");
   //code for update-operation   

    }       

//delete a user from the database   
    public void deleteUser(String email) throws SQLException{ 
        st.executeUpdate("DELETE FROM IOTUSER.USERS WHERE EMAIL='"+email+"'");
   //code for delete-operation   

    }

    //Find user by email and password in the database   
    public Shipment findShipment(String shipid, String shipdate) throws SQLException {       
        //setup the select sql query string  
        //execute this query using the statement field 
        String fetch = "SELECT * FROM IOTUSER.SHIPMENTS WHERE SHIPMENTID ='"+ shipid +"'AND SHIPDATE='"+ shipdate +"'";
        //add the results to a ResultSet     
        ResultSet rs = st.executeQuery(fetch);       
        //add the results to a ResultSet       
        //search the ResultSet for a user using the parameters   
        while(rs.next()) {
            String shipID = rs.getString(1);
            String shipDate = rs.getString(8);
            if(shipID.equals(shipid) && shipDate.equals(shipdate)){
                String shipName = rs.getString(2);
                String shipNum = rs.getString(3);
                String shipAdd = rs.getString(4);
                String shipPost = rs.getString(5);
                String shipCour = rs.getString(6);
                String shipStat = rs.getString(7);
                String shipOrderID = rs.getString(9);
                return new Shipment(shipID,shipName,shipNum,shipAdd,shipPost,shipCour,shipStat,shipDate,shipOrderID);
            }
        }            
        return null;   
    }
    
    //Add a user-data into the database   
    public void addShipment(String shipid, String shipname, String shipnum, String shipadd, String shippost, String shipcour, String shipstat, String shipdate, String orderid) throws SQLException {                   //code for add-operation       
        st.executeUpdate("INSERT INTO IOTUSER.SHIPMENTS " + " VALUES ('"+ shipid +"','"+ shipname +"','"+ shipnum +"','"+ shipadd +"','"+ shippost +"','"+ shipcour +"','"+ shipstat +"','"+ shipdate +"','"+ orderid +"')");   

    }

//update a user details in the database   
    public void updateShipment(String shipid, String shipname, String shipnum, String shipadd, String shippost, String shipcour, String shipstat, String shipdate, String orderid) throws SQLException { 
        st.executeUpdate("UPDATE IOTUSER.SHIPMENTS SET SHIPNAME='"+shipname+"',SHIPNUMBER='"+shipnum+"',SHIPADDRESS='"+shipadd+"',SHIPPOSTCODE='"+shippost+"',COURIERSERVICE='"+shipcour+"',SHIPSTATUS='"+shipstat+"',SHIPDATE='"+shipdate+"',ORDERID='"+orderid+"' WHERE EMAIL='"+shipid+"'");
   //code for update-operation   

    }       

//delete a user from the database   
    public void deleteShipment(String shipid) throws SQLException{ 
        st.executeUpdate("DELETE FROM IOTUSER.SHIPMENTS WHERE EMAIL='"+shipid+"'");
   //code for delete-operation   

    }
   
    //ITEM
    public ResultSet findItem(String search) throws SQLException
    {
       //search and list the devices based on their name and type.
       search = search.toLowerCase();
       String fetch; 
       //when nothing typed in the search 
       if(search == "")
       {
           fetch = "SELECT * FROM IOTUSER.ITEM";
       }
       else
       {
           fetch ="SELECT * FROM IOTUSER.ITEM WHERE lower(itemID) LIKE '%"+ search +
                   "'% or lower(category) LIKE '%"+search+"%'";
       }
       ResultSet rs = st.executeQuery(fetch);
       return rs;
    }
    
    //add a item into the database
    public void addItem(int itemID, String itemname, String category, boolean instock, 
            double price, int instockquantity, int manufactureid) throws SQLException
    {
        st.executeUpdate("INSERT INTO IOTUSER.ITEM"+ "VALUES ("+itemID +",'"+itemname+"','"+category+"',"+instock+
                ","+price+","+instockquantity+","+manufactureid+")");
    }
    
    //update a item details in the database
    public void updateItem(int itemID, String itemname, String category, boolean instock, 
            double price, int instockquantity, int manufactureid) throws SQLException
    {
        st.executeUpdate("UPDATE IOTUSER.ITEM SET ITEMID ="+itemID+",ITEMNAME ='"+itemname+"',CATEGORY = '"+category+"',INSTOCK ="+instock+
                ",PRICE="+price+",INSTOCKQUANTITY="+instockquantity+",MANUFACTUREID="+manufactureid+
                "WHERE ITEMID ="+itemID);
    }
    
    //delete a item from the database
    public void deleteItem(int itemID) throws SQLException
    {
        st.executeUpdate("DELETE FROM IOTUSER.ITEM WHERE ITEMID ="+ itemID);
    }
    
    //read all Items and store the results into ResultSet rs instance
    public ArrayList<Item>  listAllItems() throws SQLException
    {
        ArrayList<Item> listitem = new ArrayList<>();
        String sql ="SELECT * FROM IOTUSER.ITEM";
        ResultSet rs = st.executeQuery(sql);
        
        
        while(rs.next())
        {//int itemID, String itemname, String category, boolean instock, 
            //double price, int instockquantity, int manufactureid) throws SQLException
            int itemID = rs.getInt(1);
            String itemname = rs.getString(2);
            String category = rs.getString(3);
            boolean instock = rs.getBoolean(4);
            int price = rs.getInt(5);
            int instockquantity=rs.getInt(6);
            int manufactureid = rs.getInt(7);
            Item item = new Item(itemID,itemname,category,instock,price,instockquantity,manufactureid);
            listitem.add(item);
            
        }
        
        return listitem;
    }
}
